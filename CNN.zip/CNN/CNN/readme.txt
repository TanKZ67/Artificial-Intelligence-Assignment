CNN - MobileNet2
1. run setp_environment.bat to automatically set python environment and download packages list in requirements.txt

2. put dataset inside dataset folder
https://www.kaggle.com/datasets/grassknoted/asl-alphabet?resource=download

3. run train.py -> main.py 
Training time will need a lot of time because of large dataset